export type HeirKey = 'husband'|'wives'|'father'|'mother'|'grandfather'|'grandmother'|'son'|'daughter'|'grandson'|'granddaughter'|'fullBrother'|'fullSister'|'paternalBrother'|'paternalSister'|'maternalBrother'|'maternalSister'|'nephew'|'uncle'|'cousin';
export const HEIRS: {key:HeirKey; name:string; group:string; max?:number}[] = [
  {key:'husband',name:'الزوج',group:'الزوجية',max:1},{key:'wives',name:'الزوجات',group:'الزوجية',max:4},
  {key:'father',name:'الأب',group:'الأصول',max:1},{key:'mother',name:'الأم',group:'الأصول',max:1},{key:'grandfather',name:'الجد الصحيح',group:'الأصول',max:1},{key:'grandmother',name:'الجدة الصحيحة',group:'الأصول',max:2},
  {key:'son',name:'الأبناء',group:'الفروع'},{key:'daughter',name:'البنات',group:'الفروع'},{key:'grandson',name:'أبناء الابن',group:'الفروع'},{key:'granddaughter',name:'بنات الابن',group:'الفروع'},
  {key:'fullBrother',name:'الإخوة الأشقاء',group:'الحواشي'},{key:'fullSister',name:'الأخوات الشقيقات',group:'الحواشي'},{key:'paternalBrother',name:'الإخوة لأب',group:'الحواشي'},{key:'paternalSister',name:'الأخوات لأب',group:'الحواشي'},{key:'maternalBrother',name:'الإخوة لأم',group:'الحواشي'},{key:'maternalSister',name:'الأخوات لأم',group:'الحواشي'},
  {key:'nephew',name:'أبناء الإخوة',group:'الحواشي'},{key:'uncle',name:'الأعمام',group:'الحواشي'},{key:'cousin',name:'أبناء الأعمام',group:'الحواشي'}
];
export type Counts = Record<HeirKey,number>;
export const emptyCounts = ():Counts => Object.fromEntries(HEIRS.map(h=>[h.key,0])) as Counts;
export interface Estate { cash:number; realEstate:number; gold:number; stocks:number; funeral:number; securedDebt:number; debt:number; bequest:number; }
export const emptyEstate = ():Estate => ({cash:0,realEstate:0,gold:0,stocks:0,funeral:0,securedDebt:0,debt:0,bequest:0});
export interface CaseInput { gender:'male'|'female'; estate:Estate; heirs:Counts; }
export interface HeirResult { key:HeirKey; name:string; count:number; mode:string; fraction:number; totalShares:number; individualShares:number; percentage:number; amount:number; reason?:string; }
export interface Calculation { gross:number; net:number; origin:number; adjustedOrigin:number; correctedOrigin:number; status:'عادلة'|'عائلة'|'قاصرة مع رد'|'باقٍ للعصبة'; rows:HeirResult[]; blocked:{name:string;count:number;reason:string}[]; warnings:string[]; }
const gcd=(a:number,b:number):number=>b?gcd(b,a%b):a;
const lcm=(a:number,b:number)=>a*b/gcd(a,b);
const near=(a:number,b:number)=>Math.abs(a-b)<1e-9;
/** حساب المواريث على قواعد الفروض والعصبات والحجب؛ لا يُصدر نتيجة ظنية في صور الخلاف غير المنفذة. */
export class InheritanceCalculator {
  /** تصفية الحقوق المرتبة: التجهيز، الديون، ثم وصية غير الوارث بحد الثلث. */
  validate(input:CaseInput) {
    const e=input.estate, h=input.heirs;
    for(const [k,v] of Object.entries(e)) if(!Number.isFinite(v)||v<0) throw Error('أدخل قيمة مالية صحيحة غير سالبة: '+k);
    for(const meta of HEIRS){const n=h[meta.key];if(!Number.isSafeInteger(n)||n<0||n>(meta.max??99)) throw Error('عدد غير صالح: '+meta.name);}
    if(input.gender==='male'&&h.husband) throw Error('لا يمكن إدخال زوج لمتوفى ذكر');
    if(input.gender==='female'&&h.wives) throw Error('لا يمكن إدخال زوجات لمتوفاة');
    const gross=e.cash+e.realEstate+e.gold+e.stocks, debts=e.funeral+e.securedDebt+e.debt;
    if(debts>gross) throw Error('الديون ومؤن التجهيز تتجاوز التركة؛ لا يُوزّع المال قبل تسويتها');
    if(e.bequest>(gross-debts)/3+1e-8) throw Error('الوصية تتجاوز ثلث المتبقي بعد الديون؛ يلزم تخفيضها أو إجازة الورثة');
    if(!Object.values(h).some(Boolean)) throw Error('أضف وارثاً واحداً على الأقل');
    return {gross,net:gross-debts-e.bequest};
  }
  /** فلتر حجب الحرمان بحسب ترتيب الجهات والقرب والقوة؛ المحجوب يُعرض مع علته. */
  calculate(input:CaseInput):Calculation {
    const {gross,net}=this.validate(input), h={...input.heirs}, blocked:Calculation['blocked']=[], warnings:string[]=[];
    const has=(...keys:HeirKey[])=>keys.some(k=>h[k]>0);
    const block=(key:HeirKey,reason:string)=>{if(h[key]){blocked.push({name:HEIRS.find(x=>x.key===key)!.name,count:h[key],reason});h[key]=0;}};
    if(h.father) block('grandfather','محجوب بالأب الأقرب');
    if(h.mother) block('grandmother','محجوبة بالأم');
    else if(h.father && h.grandmother) throw Error('يلزم تحديد جهة الجدة في وجود الأب؛ الجدة لأم قد ترث بخلاف أم الأب. راجع مختصاً لهذه الصورة.');
    if(h.son){(['grandson','granddaughter'] as HeirKey[]).forEach(k=>block(k,'محجوب بالابن المباشر'));}
    if(has('father','grandfather','son','daughter','grandson','granddaughter')) {block('maternalBrother','محجوب بالأصل الذكر أو الفرع الوارث');block('maternalSister','محجوبة بالأصل الذكر أو الفرع الوارث');}
    if(has('father','son','grandson')) {(['fullBrother','fullSister','paternalBrother','paternalSister','nephew','uncle','cousin'] as HeirKey[]).forEach(k=>block(k,'محجوب بالأب أو الفرع الوارث الذكر'));}
    if(h.granddaughter && h.daughter>=2 && !h.grandson) block('granddaughter','استكملت البنات الثلثين ولا مُعصّب لبنات الابن');
    if(h.fullBrother){block('paternalBrother','محجوب بالأخ الشقيق الأقوى');block('paternalSister','محجوبة بالأخ الشقيق');}
    const sistersAsAsaba=has('daughter','granddaughter') && !h.fullBrother && !!h.fullSister;
    if(sistersAsAsaba){block('paternalBrother','محجوب بالأخت الشقيقة العصبة مع البنت');block('paternalSister','محجوبة بالأخت الشقيقة العصبة مع البنت');}
    if(h.paternalBrother && !h.fullBrother) { /* الأخت لأب معه عصبة بالغير */ }
    if(h.fullSister>=2&&!h.paternalBrother&&!has('daughter','granddaughter')) block('paternalSister','استكملت الشقيقات الثلثين ولا مُعصّب');
    if(h.grandfather && has('fullBrother','fullSister','paternalBrother','paternalSister')) throw Error('مسائل الجد مع الإخوة تتطلب تحرير المقاسمة والأحظ بحسب صورتها؛ يرجى مراجعة مختص قبل التوزيع.');
    // أبناء الإخوة والأعمام طبقات عصبة متتابعة؛ المدخل المجمع لا يميز قوة النسب إذا اجتمعت درجات مختلفة.
    if(h.nephew && has('son','grandson','father','grandfather','fullBrother','paternalBrother')) block('nephew','محجوب بالعصبة الأقرب درجةً');
    if(h.uncle && has('son','grandson','father','grandfather','fullBrother','paternalBrother','nephew')) block('uncle','محجوب بالعصبة الأقرب درجةً');
    if(h.cousin && has('son','grandson','father','grandfather','fullBrother','paternalBrother','nephew','uncle')) block('cousin','محجوب بالعصبة الأقرب درجةً');
    if(sistersAsAsaba){(['nephew','uncle','cousin'] as HeirKey[]).forEach(k=>block(k,'محجوب بالأخت الشقيقة العصبة مع الفرع المؤنث'));}
    if(h.paternalBrother || (h.paternalSister && has('daughter','granddaughter'))) {(['nephew','uncle','cousin'] as HeirKey[]).forEach(k=>block(k,'محجوب بالعصبة الأقرب'));}
    if(h.fullBrother||h.fullSister) { if(h.fullBrother || sistersAsAsaba) {(['nephew','uncle','cousin'] as HeirKey[]).forEach(k=>block(k,'محجوب بالعصبة الأقرب'));} }
    if(h.nephew){block('uncle','محجوب بابن الأخ الأقرب جهةً');block('cousin','محجوب بابن الأخ الأقرب جهةً');}
    if(h.uncle) block('cousin','محجوب بالعم الأقرب درجةً');
    const fixed:{key:HeirKey;f:number;mode:string}[]=[];
    const add=(key:HeirKey,f:number,mode='فرضاً')=>{if(h[key])fixed.push({key,f,mode});};
    const descendants=has('son','daughter','grandson','granddaughter'), maleDesc=has('son','grandson');
    add('husband',descendants?1/4:1/2); add('wives',descendants?1/8:1/4);
    const siblings=input.heirs.fullBrother+input.heirs.fullSister+input.heirs.paternalBrother+input.heirs.paternalSister+input.heirs.maternalBrother+input.heirs.maternalSister;
    const umariyya=h.father&&h.mother&&!descendants&&siblings<2&&has('husband','wives');
    if(h.mother&&!umariyya) add('mother',descendants||siblings>=2?1/6:1/3);
    if(h.grandmother) add('grandmother',1/6);
    if(h.father&&descendants) add('father',1/6,maleDesc?'فرضاً':'فرضاً وتعصيباً');
    if(h.grandfather&&descendants) add('grandfather',1/6,maleDesc?'فرضاً':'فرضاً وتعصيباً');
    if(!h.son&&h.daughter) add('daughter',h.daughter===1?1/2:2/3);
    if(!h.grandson&&h.granddaughter) add('granddaughter',h.daughter===1?1/6:h.granddaughter===1?1/2:2/3);
    if(h.maternalBrother||h.maternalSister) add('maternalBrother', h.maternalBrother+h.maternalSister===1?1/6:(h.maternalBrother/(h.maternalBrother+h.maternalSister))/3);
    // توزيع فرض الإخوة لأم بالتساوي بين الذكر والأنثى.
    if(h.maternalSister) add('maternalSister', h.maternalBrother+h.maternalSister===1?1/6:(h.maternalSister/(h.maternalBrother+h.maternalSister))/3);
    if(!h.fullBrother&&!sistersAsAsaba&&h.fullSister) add('fullSister',h.fullSister===1?1/2:2/3);
    if(!h.paternalBrother&&!h.fullBrother&&!sistersAsAsaba&&!has('daughter','granddaughter')&&h.paternalSister) add('paternalSister',h.fullSister===1?1/6:h.paternalSister===1?1/2:2/3);
    if(umariyya) add('mother',(1-(h.husband?1/2:1/4))/3);
    // المشتركة: على قضاء من شرّك الأشقاء مع الإخوة لأم عند استغراق الثلث.
    const maternalCount=h.maternalBrother+h.maternalSister;
    const mushtaraka=!!(h.husband && !descendants && !h.father && !h.grandfather && (h.mother||h.grandmother) && maternalCount>=2 && h.fullBrother && !h.paternalBrother && !h.paternalSister);
    if(mushtaraka){
      const heads=maternalCount+h.fullBrother+h.fullSister;
      fixed.splice(0,fixed.length,...fixed.filter(x=>!['maternalBrother','maternalSister','fullSister'].includes(x.key)));
      for(const key of ['maternalBrother','maternalSister','fullBrother','fullSister'] as HeirKey[]) if(h[key])add(key,h[key]/heads/3,'فرضاً بالمشاركة');
      warnings.push('المشتركة: اشترك الأشقاء والإخوة لأم في الثلث بالتساوي وفق قضاء زيد رضي الله عنه.');
    }
    const denom=(f:number)=>{for(let d=1;d<=10000;d++)if(near(f*d,Math.round(f*d)))return d;throw Error('تحتاج هذه المسألة تصحيح أسهم يتجاوز النطاق الآمن للحساب؛ راجع مختصاً.');};
    const origin=fixed.reduce((a,x)=>lcm(a,denom(x.f)),1);
    const fixedTotal=fixed.reduce((a,x)=>a+x.f,0);
    const parts:Partial<Record<HeirKey,{fraction:number;mode:string}>>={};
    for(const x of fixed)parts[x.key]={fraction:x.f,mode:x.mode};
    let status:Calculation['status']='عادلة', adjustedOrigin=origin;
    if(fixedTotal>1+1e-9){status='عائلة';adjustedOrigin=Math.round(fixedTotal*origin);for(const x of fixed)parts[x.key]!.fraction=x.f/fixedTotal;}
    else {
      let remaining=Math.max(0,1-fixedTotal);
      let asaba:HeirKey[]=[];let weighted=false;
      if(h.son){asaba=['son',...(h.daughter?['daughter' as HeirKey]:[])];weighted=true;}
      else if(h.grandson){asaba=['grandson',...(h.granddaughter?['granddaughter' as HeirKey]:[])];weighted=true;}
      else if(h.father)asaba=['father'];else if(h.grandfather)asaba=['grandfather'];
      else if(h.fullBrother){asaba=['fullBrother',...(h.fullSister?['fullSister' as HeirKey]:[])];weighted=true;}
      else if(sistersAsAsaba)asaba=['fullSister'];
      else if(h.paternalBrother){asaba=['paternalBrother',...(h.paternalSister?['paternalSister' as HeirKey]:[])];weighted=true;}
      else if(h.paternalSister&&has('daughter','granddaughter'))asaba=['paternalSister'];
      else if(h.nephew)asaba=['nephew'];else if(h.uncle)asaba=['uncle'];else if(h.cousin)asaba=['cousin'];
      if(mushtaraka)asaba=[];
      if(asaba.length && remaining>1e-9){status='باقٍ للعصبة';const totalWeight=asaba.reduce((a,k)=>a+h[k]*(weighted&&['son','grandson','fullBrother','paternalBrother'].includes(k)?2:1),0);
        for(const k of asaba){const f=remaining*h[k]*(weighted&&['son','grandson','fullBrother','paternalBrother'].includes(k)?2:1)/totalWeight;
          parts[k]={fraction:(parts[k]?.fraction??0)+f,mode:parts[k]?'فرضاً وتعصيباً':'تعصيباً'};
        }
      } else if(remaining>1e-9){
        const eligible=fixed.filter(x=>!['husband','wives'].includes(x.key));const base=eligible.reduce((a,x)=>a+x.f,0);
        if(base>0){status='قاصرة مع رد';for(const x of eligible)parts[x.key]!.fraction+=remaining*x.f/base;}
        else {warnings.push('لا يوجد وارث من أصحاب الفروض النسبية أو العصبات؛ باقي المال يحتاج مراجعة جهة الفتوى أو القضاء.');}
      }
    }
    const active=HEIRS.filter(meta=>h[meta.key]&&parts[meta.key]&&parts[meta.key]!.fraction>1e-10);
    // تصحيح الانكسار: أصغر أصل مضاعف تنقسم فيه سهام كل صنف على رؤوسه بلا كسر.
    let correctedOrigin=adjustedOrigin;
    for(const meta of active){const p=parts[meta.key]!.fraction;const per=p/h[meta.key];const d=denom(per);correctedOrigin=lcm(correctedOrigin,d);}
    const totalFraction=active.reduce((a,m)=>a+parts[m.key]!.fraction,0);
    const cents=Math.round(net*100), allocations=active.map((m,i)=>({i,exact:cents*parts[m.key]!.fraction, floor:Math.floor(cents*parts[m.key]!.fraction)}));
    let remainder=Math.max(0,Math.round(cents*totalFraction)-allocations.reduce((a,x)=>a+x.floor,0));
    const sorted=[...allocations].sort((a,b)=>(b.exact-b.floor)-(a.exact-a.floor));for(let i=0;i<remainder&&i<sorted.length;i++)sorted[i].floor++;
    const rows=active.map((meta,i)=>{const p=parts[meta.key]!;return {key:meta.key,name:meta.name,count:h[meta.key],mode:p.mode,fraction:p.fraction,totalShares:Math.round(p.fraction*correctedOrigin),individualShares:Math.round(p.fraction*correctedOrigin/h[meta.key]),percentage:p.fraction*100,amount:allocations[i].floor/100};});
    return {gross,net,origin,adjustedOrigin,correctedOrigin,status,rows,blocked,warnings};
  }
}
