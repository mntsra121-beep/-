import assert from 'node:assert/strict';
import {InheritanceCalculator,emptyCounts,emptyEstate,HeirKey} from './inheritance';
const engine=new InheritanceCalculator();
function run(heirs:Partial<Record<HeirKey,number>>,gender:'male'|'female'='male') {return engine.calculate({gender,heirs:{...emptyCounts(),...heirs},estate:{...emptyEstate(),cash:120000}});}
function share(r:ReturnType<typeof run>,key:HeirKey){return r.rows.find(x=>x.key===key)?.fraction??0;}
let r=run({husband:1,fullSister:2,mother:1},'female');assert.equal(r.status,'عائلة');assert.equal(r.origin,6);assert.equal(r.adjustedOrigin,8);assert.equal(share(r,'husband'),3/8);assert.equal(share(r,'fullSister'),4/8);assert.equal(share(r,'mother'),1/8);
r=run({wives:1,daughter:1,granddaughter:1});assert.equal(r.status,'قاصرة مع رد');assert.equal(share(r,'wives'),1/8);assert.ok(Math.abs(share(r,'daughter')-0.65625)<1e-9);assert.ok(Math.abs(share(r,'granddaughter')-0.21875)<1e-9);
r=run({daughter:1,fullSister:1,paternalBrother:1,uncle:1});assert.equal(share(r,'daughter'),1/2);assert.equal(share(r,'fullSister'),1/2);assert.equal(r.blocked.length,2);
r=run({husband:1,mother:1,father:1},'female');assert.equal(share(r,'husband'),1/2);assert.equal(share(r,'mother'),1/6);assert.ok(Math.abs(share(r,'father')-1/3)<1e-9);
r=run({wives:1,mother:1,father:1});assert.equal(share(r,'wives'),1/4);assert.equal(share(r,'mother'),1/4);assert.equal(share(r,'father'),1/2);
r=run({son:1,daughter:1,fullBrother:2});assert.equal(share(r,'son'),2/3);assert.equal(share(r,'daughter'),1/3);assert.equal(r.blocked.length,1);
r=run({daughter:3,father:1});assert.equal(r.correctedOrigin%3,0);assert.equal(r.rows.reduce((a,x)=>a+x.amount,0),120000);
assert.throws(()=>run({husband:1},'male'));
assert.throws(()=>run({wives:5}));
console.log('All inheritance tests passed');
